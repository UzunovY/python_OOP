def f1_season_app():
    return None